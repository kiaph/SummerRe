#include <iostream.h>
#include <stdlib.h>

double myrand();
